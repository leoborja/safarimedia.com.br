export const SITE_URL = {
  en: 'https://etus.digital/en',
  'pt-BR': 'https://etus.digital',
  es: 'https://etus.digital/es',
};
